# ODDYRA 2.0 — Bet Intelligence System

Aplicação web em **HTML + CSS + JavaScript puro**, pronta para hospedar no **GitHub Pages**. Não usa React, npm, servidor Node ou imagens externas de logotipo.

## O que mudou

- Logo agora é desenhado no próprio HTML/CSS: não há `assets/logo.svg` quebrado.
- Design azul-marinho responsivo, dashboard, gráficos, tabela de apostas, relatórios e exportações.
- Registro de apostas **acima da banca disponível é permitido**. Nesse caso, o sistema avisa e mostra o saldo negativo, sem impedir o cadastro.
- Cadastro rápido de apostas simples e múltiplas; status GREEN / RED / PENDENTE / ANULADA.
- Nova tela de **Entrar / Cadastrar** com autenticação verdadeira do **Supabase** quando configurada.
- **Modo visitante** utilizável sem configuração, com registros no `localStorage`.
- Tenta aproveitar seus dados locais da versão antiga usando a mesma chave `oddyra.v1`. Faça backup da versão antiga antes de atualizar.

## Publicação no GitHub Pages

1. No seu repositório [CauaPitaluga/addory](https://github.com/CauaPitaluga/addory), vá em **Code**.
2. Substitua `index.html`, `style.css` e `script.js` pelos arquivos desta pasta. Adicione `config.js` na raiz. Você pode editar pelo botão de lápis do GitHub, ou enviar os arquivos extraídos usando **Add file → Upload files**. Não envie apenas o ZIP.
3. Clique em **Commit changes** para salvar.
4. Em **Settings → Pages**, mantenha `Deploy from a branch`, `main`, `/(root)`.
5. Aguarde a publicação e atualize **https://cauapitaluga.github.io/addory/** usando Ctrl+F5.

**Importante:** `config.js` pode ficar com valores vazios para usar o sistema localmente. Nesse caso não existe login online; a tela informa que é necessária uma configuração.

## Como ativar login/cadastro e sincronização em nuvem (Supabase)

O GitHub Pages publica arquivos estáticos e **não** gerencia usuários e senhas. Para autenticação real, é necessário um serviço como Supabase. A ODDYRA 2.0 já tem a interface e o cliente REST de login/cadastro prontos, mas a ativação requer criar/configurar um projeto Supabase.

1. Crie um projeto em [supabase.com](https://supabase.com) e habilite **Authentication → Providers → Email**.
2. Em **SQL Editor**, execute o SQL abaixo para criar uma tabela com **Row Level Security (RLS)**. Isso é obrigatório para impedir acesso aos registros de outros usuários.
3. Em **Project Settings → API**, copie o **Project URL** e a **anon / publishable key** (a chave pública). Cole em `config.js`:

   ```js
   window.ODDYRA_SUPABASE = {
     url: 'https://SEU-PROJETO.supabase.co',
     anonKey: 'SUA_CHAVE_PUBLICA'
   };
   ```

   **NUNCA** use a chave `service_role` ou chave secreta no GitHub. O conteúdo do repositório e do site é público.

4. Em **Authentication → URL Configuration**, defina `Site URL` como `https://cauapitaluga.github.io/addory/` e inclua esse mesmo endereço em **Redirect URLs**. O Supabase pode exigir confirmação do e-mail antes do primeiro login.
5. Substitua o `config.js` do repositório e recarregue o site. No ícone do perfil, clique em **Entrar ou cadastrar**.
6. Se você já tem apostas no modo visitante, após entrar vá em **Configurações → Importar meus dados locais**. Isso substitui o conteúdo da conta online e mantém uma cópia local; exporte um backup antes se já houver dados na nuvem.

### SQL para o Supabase (obrigatório)

```sql
create table if not exists public.oddyra_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{"bets":[],"txs":[],"cfg":{}}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.oddyra_profiles enable row level security;

create policy "read own oddyra data"
on public.oddyra_profiles for select to authenticated
using ((select auth.uid()) = user_id);

create policy "insert own oddyra data"
on public.oddyra_profiles for insert to authenticated
with check ((select auth.uid()) = user_id);

create policy "update own oddyra data"
on public.oddyra_profiles for update to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Remova qualquer política permissiva criada por engano para anon/public.
```

Se já executou esse SQL, evite repetir as políticas sem antes verificar se elas existem. Você não precisa disponibilizar a tabela publicamente; as permissões são limitadas a cada usuário autenticado com RLS.

### Sobre a segurança e sincronização

- No modo visitante, seus dados ficam **somente nesse navegador e nesse domínio**. Outros dispositivos não enxergam os mesmos dados.
- No modo online, autenticação e banco são fornecidos pelo Supabase, com acesso protegido pelas políticas RLS acima. A aplicação não guarda senhas nos arquivos do GitHub.
- A sincronização é simples (última gravação prevalece). **Evite editar a mesma conta simultaneamente em vários aparelhos**, pois uma gravação pode sobrescrever outra.
- O sistema armazena uma sessão de login no navegador para permitir novas visitas. Use dispositivos confiáveis.
- Faça backups JSON regularmente, mesmo com a sincronização ativa.

## Regras financeiras

- **GREEN:** lucro = investimento × (odd − 1).
- **RED:** prejuízo = −investimento.
- **PENDENTE:** investimento comprometido, sem lucro/prejuízo realizado.
- **ANULADA:** valor devolvido, lucro/prejuízo zero.
- **Patrimônio:** banca inicial + depósitos − saques + lucro realizado.
- **Disponível:** patrimônio − valores comprometidos por apostas pendentes (pode ser negativo).
- **ROI:** lucro das entradas encerradas ÷ investimento nas entradas encerradas × 100.
- **Taxa de acerto:** GREEN ÷ (GREEN + RED) × 100.

**Uso:** ferramenta de registro e análise financeira, sem previsão ou promessa de retorno.

## Arquivos

- `index.html` — layout e navegação.
- `style.css` — design responsivo e dark mode.
- `script.js` — funcionalidades, cálculos, gráficos, exportações e autenticação.
- `config.js` — conexão opcional ao Supabase.

Se você atualizar um arquivo pelo GitHub, a mudança normalmente aparece depois que o Pages concluir a publicação. Use Ctrl+F5 para atualizar o cache no navegador.
