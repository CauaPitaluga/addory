/* CONFIGURAÇÃO OPCIONAL: Supabase Auth + dados por usuário.
   Preencha URL e ANON/PUBLISHABLE KEY do seu projeto Supabase.
   NUNCA coloque a service_role key neste arquivo público.
   Sem configuração, a ODDYRA funciona no modo visitante (somente neste navegador). */
window.ODDYRA_SUPABASE = {
  url: '',
  anonKey: ''
};
